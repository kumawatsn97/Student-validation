public class Main {
        public static void main(String[] args) {
            BankFactory bankFactory = new MMBankFactory();

            SavingAcc savingAcc = new MMSavingAcc(1, "SK", 10000, true);
            CurrentAcc currentAcc = new MMCurrentAcc(2, "PK", 50000, 2000);

            savingAcc.withdraw(1000);
            currentAcc.withdraw(5000);

            System.out.println(savingAcc.toString());
            System.out.println(currentAcc.toString());
        }
}